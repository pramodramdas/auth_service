package config

type DbConf struct {
}
